package modul5_pendahuluan;


public class f_or {
    public static void main(String[] args) {
        int jumlah = 0;
        for (int i=1;i<=10;i++){
             System.out.print(i+"\n");
             jumlah+=i;
         } 
        System.out.println("\ntotal penjumlahan = "+jumlah);
    }
}
