package modul5_pendahuluan;


public class do_while {

    public static void main(String[] args) {
        int a=0;
        int jumlah = 0;
        System.out.println("---Bilangan---");
        do{
            a++;
            System.out.println(a); 
            jumlah*=a;
            
        }while(a < 10);
        System.out.println("Total dari 10 angka perulangan = "+jumlah);
        
    }
}
    

