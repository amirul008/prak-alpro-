
package modul7_prak;

import javax.swing.JOptionPane;

public class nomor4 {
    public static void main(String[] args) {
        int matriks[][] = {{2, 9, 5, 17}, {1, 5, 10, 4}};

        int a = Integer.parseInt(JOptionPane.showInputDialog("Masukkan nilai yang ingin dicari posisi indeks-nya"));

        for (int i = 0; i < matriks.length; i++) {
            for (int j = 0; j < matriks[i].length; j++) {
                if (matriks[i][j] == a) {
                    System.out.println("Angka " + a + " berada pada baris ke " + i + " dan berada pada kolom ke " + j);

                }
            }
        }
        int jumlah = 0;
        for (int x = 0; x < matriks.length; x++) {
            for (int y = 0; y < matriks[0].length; y++) {
                jumlah = jumlah += matriks[x][y];

            }
        }
        System.out.println("Jumlah dari keseluruhan Matriks adalah = " + jumlah);
    }
}
