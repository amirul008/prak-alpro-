
package modul7_prak;

public class nomor2_a {
    public static void main(String[] args) {
        int data2[][]={{4,6,4,2,8,4,2,10},{4,6,4,2,8,4,2,10}};
        
        //for
        System.out.println("perulangan for");
          for (int a=0; a<data2.length; a++){
          for (int b=0; b<data2[0].length; b++){
                System.out.print(data2[a][b]+" ");
          }
          System.out.print("\n");      
          }
          System.out.println();
          //while
          System.out.println("perulangan while");
          int i=0;
         while ( i<data2.length){int j=0;
          while ( j<data2[0].length){
            System.out.print(data2[i][j]+" ");
            j++;
        }
             System.out.println();
         i++; }
         
          
         //do-while
         System.out.println();
         System.out.println("data array do - while =");
        {int k = 0;
        do {
             int l = 0;
             do {
            System.out.print(data2[k][l]+" ");
          l++;
            } while (l<data2[k].length);
             System.out.println();
            k++;
            System.out.print("");
        } while (k<data2.length);
    }
    
    }
}
