
package modul8_prak;
import javax.swing.*;
public class LuasPersegipanjang {
    private static double LuasPersegiPanjang(int panjang, int lebar) {
        double luasPersegiP = panjang * lebar;
        System.out.println("Persegi Panjang");
        System.out.println("Panjang = " + panjang);
        System.out.println("Lebar   = " + lebar);
        System.out.println("Luas Persegi Panjang = " + luasPersegiP);
        return luasPersegiP;
    }

    public static void main(String[] args) {

        double luasPersegiP;
        int panjang = Integer.parseInt(JOptionPane.showInputDialog
        ("Untuk menghitung Luas Persegi Panjang\n(Masukkan Panjang Persegi Panjang)"));
        int lebar = Integer.parseInt(JOptionPane.showInputDialog
        ("Masukkan Lebar Persegi Panjang"));
        luasPersegiP = LuasPersegiPanjang(panjang, lebar);

    }
}
