
package modul8_prak;

import java.util.Scanner;

public class VolumeBola {
    // Fungsi
    public double volume_bola (double r) {
        
        double v=4*(Math.PI* Math.pow (r, 3))/3;
        return v;  
    }
// Prosedur
    public void hitungVolume (double r) { 
        double v=4*(Math.PI* Math.pow (r, 3))/3;
//        System.out.println (v);
        
    }
    
    public static void main(String[] args)  {
        Scanner input=new Scanner(System.in);
        
        System.out.println("Menghitung Volume Bola");
        System.out.print("\nMasukkan Diameter: ");
        double d =input.nextDouble(); 
        double r=d/2;
        
        VolumeBola Vol=new VolumeBola(); 
        
        System.out.println ( "\nVolume Bola = "+Vol.volume_bola(r)+" cm"); 
        
    }
}
