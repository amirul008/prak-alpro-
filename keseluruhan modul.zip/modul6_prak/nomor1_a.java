package modul6_prak;


public class nomor1_a {
    public static void main(String[] args) {
        int[] data= {20,10,50,30,10};
        System.out.print(" Isi data anda adalah : ");
        for (int i=0; i<data.length; i++){
        System.out.print(data[i]+" ");
    }
        System.out.println();
    }
}
