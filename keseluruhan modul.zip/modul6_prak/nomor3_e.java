package modul6_prak;


import java.util.Arrays;
import javax.swing.*;


public class nomor3_e {
    public static void main(String[] args) {
        int input_array= Integer.parseInt(JOptionPane.showInputDialog("Masukkan Jumlah array"));
        int data[] = new int[input_array];
        System.out.println(" Jumlah Array = "+ input_array);
        int tertinggi = 0;
        int terendah = 0;
        int i, index_max= 0, index_min =0;
        int total =0, rata_rata =0;
        
        
        for (i=0; i<data.length; i++){
            int input_nilai_index = Integer.parseInt(JOptionPane.showInputDialog( null," Masukkan Nilai Index " +i ));
            data[i]= input_nilai_index;
            System.out.println(" Indeks ke = "+i+" nilai = " +data[i]);
        } 
        
        
        for ( i=0; i<data.length; i++){
            if (data[i]< terendah){
                terendah= data[i]; index_min = i;
                
            } 
            if (data[i]> tertinggi){
            tertinggi = data[i]; index_max = i;
            
        }
           
        }
            System.out.println();
          
          int jumlah = 0;
          for ( i=0; i<data.length; i++){
              if (data[i] %2 != 0 ){
                  System.out.println(" index ganjil = "+data[i]);
                  jumlah += data [i];
              } 
          }
          for ( i=0; i<data.length; i++){
              if (data[i] %2 == 0 ){
                  System.out.println(" index genap = "+data[i]);
              } 
               total = total + data[i];
               rata_rata = total/data.length;
          }
            System.out.println(" Total jumlah nilai ganjil "+jumlah);
            
             if (jumlah %2 != 0 ){
         System.out.println("Angka " + jumlah + " adalah angka ganjil" );        
         } else if (jumlah %2 == 0){
         System.out.println("Angka " + jumlah + " adalah angka genap" ); 
        }
       
                          System.out.print("\nUrutannya : ");
          Arrays.sort(data);
        for (int index : data){
            System.out.print(index+ " ");
            
        }
    }
}

