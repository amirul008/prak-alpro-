package modul6_prak;


import javax.swing.JOptionPane;


public class nomor3_c {
    public static void main(String[] args) {
        //a
        int input_array= Integer.parseInt(JOptionPane.showInputDialog("Masukkan Jumlah array"));
        int data[] = new int[input_array];
        System.out.println(" Jumlah Array = "+ input_array);
        int tertinggi = 0;
        int terendah = 1;
        int i,j, index_max= 0, index_min =0;
        int total =0, rata_rata =0;
        int temp;
        //b
        for (i=0; i<data.length; i++){
            int input_nilai_index = Integer.parseInt(JOptionPane.showInputDialog( null," Masukkan Nilai Index " +i ));
            data[i]= input_nilai_index;
            System.out.println(" Indeks ke = "+i+" nilai = " +data[i]);
        }
        //c
        System.out.println("===========================\n");
        for ( i=0; i<data.length; i++){
            if (data[i]< terendah){
                terendah= data[i]; index_min = i;
            } 
            if (data[i]> tertinggi){
            tertinggi = data[i]; index_max = i;
        }
            //d
            total = total + data[i];
            rata_rata = total/data.length;
        }
        //e dan f
        int jumlah = 0;
          for ( i=0; i<data.length; i++){
              if (data[i] %2 != 0 ){
                  System.out.println(" Nilai index yang ganjil = "+data[i]);
                  jumlah += data [i];
              } 
          }
          System.out.println("===========================\n");
        System.out.println();
        System.out.println("Nilai Tertinggi   = "+tertinggi+ " Index ke = "+ index_max);
        System.out.println("Nilai Terendah    = "+terendah+  " Index ke = " + index_min);
        System.out.println("\nJumlah semua data = "+total);
        System.out.println("Nilai rata-rata   = "+rata_rata);
        System.out.println("Total jumlah nilai ganjil "+jumlah);
        
        for (i=0;i<data.length;i++) {
   for (j=0;j<data.length;j++){
    if (data[i]>data[i+1]){
     temp = data[i];
     data[i] = data[i+1];
     data[i+1] = temp;
    }
   }
  }
  
  System.out.println("\n\nSetelah diurutkan :");
  for (i=0;i<data.length;i++){
   System.out.print(data[i] + " ");
  }
       
    }
}
