package modul6_prak;


import javax.swing.JOptionPane;


public class nomor2_c {
    public static void main(String[] args) {
        int data[] = new int[10];
        for ( int a=0; a<data.length; a++){
            data[a]=Integer.parseInt(JOptionPane.showInputDialog(" Masukkan nilai index ke "+a));
            System.out.println(" Index ke "+a+ " adalah "+data[a]);}
        int i, input = 0;
        
         int pencarian = Integer.parseInt(JOptionPane.showInputDialog( " Masukkan Nilai yang dicari = "));
         System.out.println(" ");
         for (i= 0; i<data.length; i++){
             if (data[i]== pencarian){
                 System.out.println(pencarian +" Sudah ketemu di indeks ke " + i);
             }
         }
         input = Integer.parseInt(JOptionPane.showInputDialog("Ganti Nilai "+ pencarian + " Dengan Nilai berapa ? "));
         System.out.println(" ");
         for ( i=0; i<data.length; i++){
             if (data[i] == pencarian){
                 data[i] = input;
             }
             System.out.println(" Indeks ke  "+i+ " = " +data[i]);
         }
    }
}
