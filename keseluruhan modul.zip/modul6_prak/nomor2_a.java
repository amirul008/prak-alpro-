package modul6_prak;


import javax.swing.*;

public class nomor2_a {
    public static void main(String[] args) {
        int data[] = new int[10];
        for ( int a=0; a<data.length; a++){
            data[a]=Integer.parseInt(JOptionPane.showInputDialog(" Masukkan nilai index ke "+a));
            System.out.println(" Index ke "+a+ " adalah "+data[a]);}
        int terendah = data[0];
        int tertinggi = data[0];
        int i, index_max = 0, index_min = 0;
       
        
        for ( i=0; i<data.length; i++){
            if (data[i]< terendah){
                terendah= data[i]; index_min = i;
            } else if (data[i]> tertinggi){
            tertinggi = data[i]; index_max = i;
        }
        }
        System.out.println();
        System.out.println("Nilai Tertinggi = "+tertinggi+ " Index ke = "+ index_max);
        System.out.println("Nilai Terendah = "+terendah+ " Index ke = " + index_min);
    }
}
