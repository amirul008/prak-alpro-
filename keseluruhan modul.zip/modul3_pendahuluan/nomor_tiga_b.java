/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul3_pendahuluan;

import javax.swing.JOptionPane;

public class nomor_tiga_b {
    public static void main (String[]args){
     int nilai;
     nilai = Integer.parseInt(JOptionPane.showInputDialog("masukkan tinggi badan anda"));
      if (nilai > 160){
      JOptionPane.showMessageDialog(null, "Anda lolos seleksi");
       }
 else
 JOptionPane.showMessageDialog(null, "Anda tidak lolos");
 }
}
