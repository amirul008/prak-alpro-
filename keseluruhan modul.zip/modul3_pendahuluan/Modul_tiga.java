/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul3_pendahuluan;
import javax.swing.JOptionPane;

public class Modul_tiga {

   
    public static void main(String[] args) {
       int pilihan;
       String pilihan_string, pesan;
        pesan = "\n1. Merah "+"\n2. Kuning "+"\n3. Biru "+"\n\n Masukkan nomor warna yang anda suka = ";
        pilihan_string=
        JOptionPane.showInputDialog(null,pesan);
        pilihan =Integer.parseInt(pilihan_string);
        switch (pilihan) {
        case 1:pesan ="kamu adalah orang yang kuat";
        break;
        case 2:pesan ="kamu adalah orang yang ceria";
        break;
        case 3:pesan ="kamu adalah orang yang cerdas";
        break;
        default : pesan ="Anda salah memasukkan nomor";
         }
        JOptionPane.showMessageDialog(null,pesan);
    }
    
}
