
package modul3_pendahuluan;

import javax.swing.JOptionPane;

public class nomor_tiga_a {
    public static void main (String[]args){
 int nilai;
nilai = Integer.parseInt(JOptionPane.showInputDialog("masukkan tinggi badan anda"));

 if (nilai > 160){
JOptionPane.showMessageDialog(null, "Anda lolos seleksi");

 }
}
}