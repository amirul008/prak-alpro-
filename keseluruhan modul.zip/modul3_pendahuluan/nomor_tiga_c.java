
package modul3_pendahuluan;

import javax.swing.JOptionPane;

public class nomor_tiga_c {
         
public static void main (String[]args){
     int nilai;
     nilai = 
     Integer.parseInt(JOptionPane.showInputDialog("masukkan nilai hasil ujian anda"));

     if (nilai > 100){
    JOptionPane.showMessageDialog(null, "Anda salah memasukkan nilai");}

    else if(nilai >= 90) {
    JOptionPane.showMessageDialog(null, "Nilai anda A");}

 }
}
    