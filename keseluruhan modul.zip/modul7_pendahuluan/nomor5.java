package modul7_pendahuluan;


public class nomor5 {
    public static void main(String[] args) {
         int data2[][]= {{4,6,4,7,8,3,2,10},{4,6,4,2,8,8,2,10}};
         
         //for
         System.out.println("data array for = ");
         for (int i=0; i<data2.length; i++){
        for (int j=0; j<data2[i].length; j++){
            System.out.print(data2[i][j]+" ");

          }
        }
         //while
         System.out.println("\ndata array while = ");
         int i=0;
         while ( i<data2.length){int j=0;
         while ( j<data2[i].length){
            System.out.print(data2[i][j]+" ");
            j++;
        }
         i++;
    }
      
    }
}
