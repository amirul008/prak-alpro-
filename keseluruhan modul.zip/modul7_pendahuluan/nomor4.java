package modul7_pendahuluan;


import javax.swing.JOptionPane;


public class nomor4 {
    public static void main(String[] args) {
        int data2[][]= {{4,6,4,7,8,3,2,10},{4,6,4,2,8,8,2,10}};
       int nilai = Integer.parseInt(JOptionPane.showInputDialog("Masukkan Nilai :"));
        boolean benar = false;
        for (int i=0; i<data2.length; i++){
             for (int j=0; j<data2[i].length; j++){
               if (data2[i][j]== nilai){
                   JOptionPane.showMessageDialog(null, " Nilai : " +nilai+ "\nada pada baris = " +i+ "\nKolom : "+j );
              benar = true;
          }
        }        
    }
    }
} 

