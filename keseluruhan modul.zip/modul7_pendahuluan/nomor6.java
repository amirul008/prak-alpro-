  package modul7_pendahuluan;


public class nomor6 {
    public static void main(String[] args) {
        int data[][]= {{4,6,4,7,8,3,2,10},{4,6,4,2,8,8,2,10}};
        double jumlah1 = 0, jumlah2 = 0;
        double total=0,total2=0, rata_rata=0;
        System.out.print("Baris satu : ");
        for (int i = 0; i<data[0].length; i++){
            System.out.print(data[0][i]+",");
            jumlah1 += data[0][i];
        }
        System.out.print("\nBaris dua  : ");
        for (int i = 0; i<data[1].length; i++){
            System.out.print(data[1][i]+",");
            jumlah2 += data[1][i];
        }
        total=jumlah1+jumlah2;
        total2 = data[0].length+data[1].length;
        
        rata_rata= total/total2;
        System.out.println("\nrata rata :  "+rata_rata);
        

    }
}
