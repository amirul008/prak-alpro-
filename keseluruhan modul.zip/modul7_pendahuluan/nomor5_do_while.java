package modul7_pendahuluan;


public class nomor5_do_while {
    public static void main(String[] args) {
        int data2[][]= {{4,6,4,7,8,3,2,10},{4,6,4,2,8,8,2,10}};
        System.out.println("data array do - while =");
       int i = 0;
        do {
             int j = 0;
             do {
            System.out.print(data2[i][j]+" ");
          j++;
            } while (j<data2[i].length);
            i++;
            System.out.print("");
        } while (i<data2.length);
    }
    }

