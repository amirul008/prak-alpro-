package modul5_prak;


import java.util.Scanner;


public class nomor3_a {
    public static void main(String[] args) {
         Scanner scan = new Scanner (System.in);
        
        System.out.println("Input Nilai 1 - 10!");
        int a = scan.nextInt();
        
        if (a == 1) {
            System.out.println("Satu");
        } else if (a == 2) {
            System.out.println("Dua");
        } else if (a == 3) {
            System.out.println("Tiga");
        } else if (a == 4) {
            System.out.println("Empat");
        } else if (a == 5) {
            System.out.println("Lima");
        } else if (a == 6) {
            System.out.println("Enam");
        } else if (a == 7) {
            System.out.println("Tujuh");
        } else if (a == 8) {
            System.out.println("Delapan.");
        } else if (a == 9) {
            System.out.println("Sembilan");
        } else if (a == 10) {
            System.out.println("Sepuluh");
        } else {
            System.out.println("Invalid Number");
        }
    }
}
