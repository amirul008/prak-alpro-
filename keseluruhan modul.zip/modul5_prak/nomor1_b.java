package modul5_prak;


public class nomor1_b {
    public static void main(String[] args) {
        {
            for(double jari=1.0;jari<=2.0;jari+=0.2){
                System.out.println("Radius ="+jari+"Luas ="+jari*Math.PI*jari);
            }
        }
    }
    
}
