package modul5_prak;


import java.util.Scanner;


public class nomor2_c {
    public static void main(String[] args) {
        float a1 = 4, b1 = 2, c1 = a1, d1 = 1;
        float a2 = 5, b2 = 1, c2 = a2, d2 = 1;
        
        while (d1 < b1) {
            c1*=a1;
            d1++;
        } while (d2 < b2) {
            c2*=a2;
        } System.out.println("(" + a1 + "^" + b1 + " + " + a2 + "^" + b2 + ")" + 
                             " / " + a2 + "^" + b2 + " + " + a1 + "^" + b1 + " = " + 
                             ((c1 + c2) / c2 + c1));

}
}
