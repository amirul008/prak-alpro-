package modul5_prak;


import java.util.Scanner;


public class nomor3_b {
    public static void main(String[] args) {
         Scanner scan = new Scanner(System.in);  
        
        System.out.println("Input Nilai 1 - 10 =");
        int nilai = scan.nextInt();
        switch (nilai) {
            case 1 :
                System.out.println("Satu");
                break;
            case 2 : 
                System.out.println("Dua");
                break;
            case 3 :
                System.out.println("Tiga");
                break;
            case 4 :
                System.out.println("Empat");
                break;
            case 5 :
                System.out.println("Lima");
                break;
            case 6 :
                System.out.println("Enam");
                break;
            case 7 :
                System.out.println("Tujuh");
                break;
            case 8 :
                System.out.println("Delapan");
                break;
            case 9 :
                System.out.println("Sembilan");
                break;
            case 10 :
                System.out.println("Sepuluh");
                break;
            default :
                System.out.println("Invalid Number");}
        
    }
}
