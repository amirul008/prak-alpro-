package modul5_prak;


import java.util.Scanner;

public class nomor4_a {
    public static void main(String[] args) {
        int total = 0;
        int angka = 0;
      for (int i = 0; i < 3; i++){
     Scanner a = new Scanner(System.in); 
     System.out.print("Masukkan Angka : ");
       angka = a.nextInt();
     if (angka %2 != 0 ){
         System.out.println("Angka " + angka + " adalah angka ganjil" );        
     } else if (angka %2 == 0){
         System.out.println("Angka " + angka + " adalah angka genap" ); 
     }
    total = total + angka;
          System.out.println("Total  = " + total ); 
    }
        }
    }

