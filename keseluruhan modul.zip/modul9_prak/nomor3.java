
package modul9_prak;
import java.awt.Color;
import javax.swing.*;

public class nomor3 extends JFrame{
     JTextField textField = new JTextField();
    JButton zero = new JButton("0");
    JButton satu = new JButton("1");
    JButton dua = new JButton("2");
    JButton tiga = new JButton("3");
    JButton empat = new JButton("4");
    JButton lima = new JButton("5");
    JButton enam = new JButton("6");
    JButton tujuh = new JButton("7");
    JButton delapan = new JButton("8");
    JButton sembilan = new JButton("9");
    JButton tambah = new JButton("+");
    JButton kurang = new JButton("-");
    JButton kali = new JButton("*");
    JButton bagi = new JButton("/");
    JButton samaDengan = new JButton("=");
    JButton c = new JButton("C");

    nomor3() {
        setTitle("Design Preview");
        setSize(230, 270);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        setVisible(true);
    }

    void objek() {
        setLayout(null);
        textField.setBounds(10, 10, 193, 30);
        textField.setBackground(Color.WHITE);
        add(textField);
        satu.setBounds(10, 60, 41, 25);
        satu.setBackground(Color.GREEN);
        add(satu);
        dua.setBounds(60, 60, 41, 25);
        dua.setBackground(Color.GREEN);
        add(dua);
        tiga.setBounds(110, 60, 41, 25);
        tiga.setBackground(Color.GREEN);
        add(tiga);
        tambah.setBounds(160, 60, 41, 25);
        tambah.setBackground(Color.ORANGE);
        add(tambah);
        empat.setBounds(10, 100, 41, 25);
        empat.setBackground(Color.GREEN);
        add(empat);
        lima.setBounds(60, 100, 41, 25);
        lima.setBackground(Color.GREEN);
        add(lima);
        enam.setBounds(110, 100, 41, 25);
        enam.setBackground(Color.GREEN);
        add(enam);
        kurang.setBounds(160, 100, 41, 25);
        kurang.setBackground(Color.ORANGE);
        add(kurang);
        tujuh.setBounds(10, 140, 41, 25);
        tujuh.setBackground(Color.GREEN);
        add(tujuh);
        delapan.setBounds(60, 140, 41, 25);
        delapan.setBackground(Color.GREEN);
        add(delapan);
        sembilan.setBounds(110, 140, 41, 25);
        sembilan.setBackground(Color.GREEN);
        add(sembilan);
        kali.setBounds(160, 140, 41, 25);
        kali.setBackground(Color.ORANGE);
        add(kali);
        zero.setBounds(10, 180, 41, 25);
        zero.setBackground(Color.GREEN);
        add(zero);
        c.setBounds(60, 180, 41, 25);
        c.setBackground(Color.YELLOW);
        add(c);
        samaDengan.setBounds(110, 180, 41, 25);
        samaDengan.setBackground(Color.GREEN);
        add(samaDengan);
        bagi.setBounds(160, 180, 41, 25);
        bagi.setBackground(Color.ORANGE);
        add(bagi);       
    }

    public static void main(String[] args) {
        nomor3 x = new nomor3();
        x.objek();
    }
}
