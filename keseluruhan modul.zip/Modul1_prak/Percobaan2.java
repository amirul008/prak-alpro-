/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul1_prak;

/**
 *
 * @author ASUS
 */
public class Percobaan2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       System.out.print("Nama buah\n\t");
       System.out.print("\b 1. Manggis\n\t");
       System.out.print("2. Semangka\n");
       System.out.print("3. Durian\n");
       System.out.print("4. Salak\n");
    }
    
}
