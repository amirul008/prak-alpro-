/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul1_prak;

/**
 *
 * @author ASUS
 */
public class Percobaan1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       System.out.println("Nama: Muhammad Amirul Muttaqin");
       System.out.println("Gender : Laki - Laki");
       System.out.println("Alamat : Gresik");
       System.out.println("Tanggal lahir : 25 November 2003");
    }
    
}
