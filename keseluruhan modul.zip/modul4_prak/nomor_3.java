package modul4_prak;




import javax.swing.JOptionPane;

public class nomor_3 {
    
    public static void main(String[] args) {
        String harga =JOptionPane.showInputDialog("masukkan nilai jual barang");
        int nilai_jual = Integer.parseInt(harga);
        double nilai_dapat = 0;
        
        if (nilai_jual<=2000000){
            nilai_dapat = (nilai_jual*0.1)+100000;
            JOptionPane.showMessageDialog(null, " yang didapat =" +nilai_dapat);
         }
        else if (nilai_jual>2000000 && nilai_jual<=5000000 ){
            nilai_dapat = (nilai_jual*0.15)+200000;
            JOptionPane.showMessageDialog(null, " yang didapat =" +nilai_dapat);}
            
        else if(nilai_jual>5000000){
            nilai_dapat = (nilai_jual*0.2)+300000;
            JOptionPane.showMessageDialog(null, " yang didapat =" +nilai_dapat);}
        }
        
    }
