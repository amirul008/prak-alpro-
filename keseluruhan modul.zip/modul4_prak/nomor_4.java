package modul4_prak;



import javax.swing.JOptionPane;


public class nomor_4 {
    
    public static void main(String[] args) {
    int min = 0;
    int max = 0;
    int adi = Integer.parseInt(JOptionPane.showInputDialog("Masukkan Nilai Adi"));
    int budi = Integer.parseInt(JOptionPane.showInputDialog("Masukkan Nilai Budi"));
    int caca = Integer.parseInt(JOptionPane.showInputDialog("Masukkan Nilai Caca"));
    int deny = Integer.parseInt(JOptionPane.showInputDialog("Masukkan Nilai Deny"));
    
    String Nilai_adi = "";
    String Nilai_budi = "";
    String Nilai_caca = "";
    String Nilai_deny = "";
    
    //nilai si adi
        if(adi >= 36 && adi <=45){
            Nilai_adi = "D";
        }else if (adi >=46 && adi <=55){
            Nilai_adi = "C";
        }else if (adi >=56 && adi <=65){
            Nilai_adi = "C+";
        }else if (adi >=66 && adi <=75){
            Nilai_adi = "B";
        }else if (adi >=76 && adi <=85){
            Nilai_adi = "B+";
        }else if (adi >=86 && adi <=100){
            Nilai_adi = "A";
        }else{
            Nilai_adi = "E";
        
        }    
        
    //nilai si Budi
        if(budi >= 36 && budi <=45){
            Nilai_budi = "D";
        }else if (budi >=46 && budi <=55){
            Nilai_budi = "C";
        }else if (budi >=56 && budi <=65){
            Nilai_budi = "C+";
        }else if (budi >=66 && budi <=75){
            Nilai_budi = "B";
        }else if (budi >=76 && budi <=85){
            Nilai_budi = "B+";
        }else if (budi >=86 && budi <=100){
            Nilai_budi = "A";
        }else{
            Nilai_budi = "E";
        
        }
        
    //nilai si caca
        if(caca >= 36 && caca <=45){
            Nilai_caca = "D";
        }else if (caca >=46 && caca <=55){
            Nilai_caca = "C";
        }else if (caca >=56 && caca <=65){
            Nilai_caca = "C+";
        }else if (caca >=66 && caca <=75){
            Nilai_caca = "B";
        }else if (caca >=76 && caca <=85){
            Nilai_caca = "B+";
        }else if (caca >=86 && caca <=100){
            Nilai_caca = "A";
        }else{
            Nilai_caca = "E";
        
        }
        
    //nilai si deny
        if(deny >= 36 && deny <=45){
            Nilai_deny = "D";
        }else if (deny >=46 && deny <=55){
            Nilai_deny = "C";
        }else if (deny >=56 && deny <=65){
            Nilai_deny = "C+";
        }else if (deny >=66 && deny <=75){
            Nilai_deny = "B";
        }else if (deny >=76 && deny <=85){
            Nilai_deny = "B+";
        }else if (deny >=86 && deny <=100){
            Nilai_deny = "A";
        }else{
            Nilai_deny = "E";
        
        }
        
       
         //mencari nilai terendah
        if(adi<budi && adi<caca && adi<deny){
            min = adi;
        }else if (budi<caca && budi<deny){
            min = budi;
        }else if (caca<deny){
            min = caca;
        }else{
            System.out.println("error");          
        }
        
        
        //mencari nilai tertinggi
        if(adi>budi && adi>caca && adi>deny){
            max = adi;
        }else if (budi>caca && budi>deny){
            max = budi;
        }else if (caca>deny){
            max = caca;
        }else{
            System.out.println("error");          
        }
        
       
        
    JOptionPane.showMessageDialog(null,"Nilai Adi = "+adi+" Nilai Huruf = "+Nilai_adi+
            "\nNilai Budi = "+budi+" Nilai Huruf = "+Nilai_budi+
            "\nNilai Caca = "+caca+" Nilai Huruf = "+Nilai_caca+
            "\nNilai Deny = "+deny+" Nilai Huruf = "+Nilai_deny+
            "\n\nNilai Tertinggi Adalah = "+max+
            "\nNilai Terendah Adalah = "+min); 
    }
    
}
    

