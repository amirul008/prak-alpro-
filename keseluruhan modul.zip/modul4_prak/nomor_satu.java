package modul4_prak;


import java.io.*;

public class nomor_satu {
    
    public static void main(String[] args) throws IOException {
        
        BufferedReader dataAngka = new BufferedReader(new InputStreamReader(System.in));
    System.out.println("Memasukkan nilai ");
    System.out.print("Masukkan Nilai Pertama = ");
    String str1 = dataAngka.readLine(); 
    int a = Integer.parseInt(str1);
    System.out.print("Masukkan Nilai Kedua   = " );
    String str2 = dataAngka.readLine();
    int b = Integer.parseInt(str2);  
    System.out.print("Masukkan Nilai Ketiga  = " );
    String str3 = dataAngka.readLine();
    int c = Integer.parseInt(str3);

System.out.println("Nilai - nilai yang dimasukkan = " + a + "," + b + "," + c);
    }
}
