package modul4_prak;


import java.io.*;

public class nomor_2 {
    
    public static void main(String[] args) throws IOException {
        
         BufferedReader dataAngka = new BufferedReader(new InputStreamReader(System.in));
    System.out.println("Memasukkan nilai ");
    System.out.print("Masukkan Nilai Pertama = ");
    String str1 = dataAngka.readLine(); 
    int a = Integer.parseInt(str1);
    System.out.print("Masukkan Nilai Kedua   = " );
    String str2 = dataAngka.readLine();
    int b = Integer.parseInt(str2);  
    System.out.print("Masukkan Nilai Ketiga  = " );
    String str3 = dataAngka.readLine();
    int c = Integer.parseInt(str3);

System.out.println("Nilai - nilai yang dimasukkan = " + a + "," + b + "," + c); 

     if(a>b && a>c){
         System.out.println("Nilai terbesar = "+a);
     }else if(b>c){
         System.out.println("Nilai terbesar = "+b);
     }else{
         System.out.println("Nilai terbesar = "+c);
     }
     
     if(a<b && a<c){
         System.out.println("Nilai terkecil = "+a);
     }else if(b<c){
         System.out.println("Nilai terkecil = "+b);
     }else{
         System.out.println("Nilai terkecil = "+c);
     }
    }
}

