
package modul8_pendahuluan;

public class nomor5_a {
String nama, makanan;
    
    public static void main(String[] args){
        // Membuat Objek dari Class tutorial_dasar
        nomor5_a Hewan = new nomor5_a();
        System.out.println("====== ULAR =======");
        Hewan.ular();
    }
    
    void ular(){
        nama = "Coki";
        makanan = "tikus";
        System.out.println("Nama ular saya adalah "+nama);
        System.out.println("ular saya suka makan "+makanan);
    }
}
 


