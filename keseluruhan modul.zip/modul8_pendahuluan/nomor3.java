package modul8_pendahuluan;
import java.util.Scanner;
public class nomor3 {
    public static void main(String[] args) {
Scanner input = new Scanner(System.in);
	try{
	  System.out.print("Masukkan NIM anda = ");
	int angka = input.nextInt();
          System.out.println("Angka yang dimasukkan adalah = " + angka);}
			
        catch(Exception ex){
	  System.out.println("Coba lagi. (Input Salah: Sebuah angka integer diperlukan)");}                 
        finally {
          System.out.println("Terima Kasih telah mengisi");}
                        
    }
}

