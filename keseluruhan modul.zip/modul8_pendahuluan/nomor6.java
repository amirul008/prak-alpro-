
package modul8_pendahuluan;

public class nomor6 {
    
        static void cetak (int a) {
      System.out.println("Nilai x : "+a);
      }
       public static void main(String[] args) {
       int x;
       for (x=0; x<5; x++) {
       cetak (x);}
      System.out.println("Nilai x terakhir: "+x);
    }
 
}
