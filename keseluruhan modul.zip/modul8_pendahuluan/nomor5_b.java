
package modul8_pendahuluan;

public class nomor5_b {
    public static void main(String args[]){
		String nama="Nama saya adalah Muhammad Amirul Muttaqin";
                String asal="Saya berasal dari Gresik";
		System.out.println(nama);
		System.out.println(asal);
	}
 
}

