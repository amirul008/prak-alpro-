
package modul8_pendahuluan;

public class nomor5_c {
    public static void main(String[] args){
double a = 10.0d;
double b = 5.0d;

System.out.println(a + " * " + b + " = " + (a*b));
System.out.println(a + " / " + b + " = " + (a/b));

}
}

