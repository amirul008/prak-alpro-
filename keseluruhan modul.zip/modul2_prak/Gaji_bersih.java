
package modul2_prak;

import java.util.Scanner;

public class Gaji_bersih {


    public static void main(String[] args) {
      final double gaji_kotor ;
        
        Scanner input = new Scanner (System.in);
        
        System.out.println("===== Menghitung gaji bersih setelah dipotong pajak =====\n");
        
        System.out.print("Masukan gaji kotor :  ");

        gaji_kotor = input.nextDouble();
        
        double pajak = 0.1;
        
        double potongan = pajak * gaji_kotor;
        
        double gaji_bersih = gaji_kotor-potongan;
        
        System.out.println("gaji bersih yang diterima :"+ gaji_bersih);
    }
    
}
