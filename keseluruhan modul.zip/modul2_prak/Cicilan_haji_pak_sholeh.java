
package modul2_prak;

public class Cicilan_haji_pak_sholeh {

    public static void main(String[] args) {
        int b_haji = 50000000;
        int tabungan_a = 20000000;
        int onh = 10000000;
        int tabungan_h;
        int cicilan;
        tabungan_h = b_haji-onh;
        cicilan = tabungan_h/23;
        System.out.println(" Biaya haji\t :" + b_haji);
        System.out.println(" Tabungan pak sholeh :" + tabungan_a);
        System.out.println(" ONH\t\t :" + onh);
        System.out.println(" Kekurangan Total:" + tabungan_h );
        System.out.println(" Cicilan/bulan\t : " + cicilan);
        
        
    }
    
}
