/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul2_pendahuluan;

/**
 *
 * @author ASUS
 */
public class Incrementdecrement {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int angka1 = 30;
        int angka2 = 30;
        int angka3 = 30;
        int angka4 = 30;
        int hasil = ++angka1 + angka2;
        int hasil2 = --angka3 + angka4;
        
        System.out.println(hasil);
        System.out.println(hasil2);
    }
    
}
