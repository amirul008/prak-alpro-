package modul6_pendahuluan;

import javax.swing.*;
public class nomor_4 {
    public static void main(String[] args) {
        int data[]={4,6,4,2,8,4,2,11};
        int nilai = Integer.parseInt(JOptionPane.showInputDialog("Masukkan Nilai :"));
        int index = -1;
        for (int i=0; i<data.length; i++){
          if (data[i] == nilai){
              index = i;
          }
        }
           JOptionPane.showMessageDialog(null, " Nilai : " +nilai+ " , ada di indeks = " +index);
        }
    }


