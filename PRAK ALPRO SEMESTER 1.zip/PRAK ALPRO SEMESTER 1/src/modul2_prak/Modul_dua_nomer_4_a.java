
package modul2_prak;

public class Modul_dua_nomer_4_a {

    public static void main(String[] args) {
       int a = 2;
       int b = 8;
       int c = (int) Math.pow(a, b);
       
       int d = 4;
       int e = 4;
       int f = (int)Math.pow(d, e);
        System.out.println(c+f);
    }
    
}
