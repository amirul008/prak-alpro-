
package modul2_prak;


public class rata_rata_angka {

    public static void main(String[] args) {
        
        int a = 30;
        int b = 30;
        int c = 60;
        int total_nilai = a+b+c;
        int nilai_ratarata= total_nilai/3;
        System.out.println("Total nilai :" +total_nilai);
        System.out.println("Nilai rata rata :" +nilai_ratarata);
        
        
    }
    
}
