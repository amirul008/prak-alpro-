
package modul2_prak;

public class Modul_dua_nomer_4_b {

    public static void main(String[] args) {
       int a = 2;
       int b = 2;
       int hasil_1 = (int) Math.pow(a, b);
       
       int d = 4;
       int e = 1;
       int hasil_2 = (int)Math.pow(d, e);
       
       int f = 2;
       int g = 2;
       int hasil_3 = (int)Math.pow(f, g);
       
       System.out.println(hasil_1+hasil_2/hasil_3);
       


    }
    
}
