
package modul3_pendahuluan;

import javax.swing.JOptionPane;


public class nomor_tiga_d {
    public static void main (String[]args){
     int nilai;
     nilai = 
     Integer.parseInt(JOptionPane.showInputDialog("masukkan nilai hasil ujian anda"));

     if (nilai > 100){
    JOptionPane.showMessageDialog(null, "Anda salah memasukkan nilai");}

    else if(nilai >= 90) {
    JOptionPane.showMessageDialog(null, "Nilai anda A");}
    else if (nilai >= 74){
    JOptionPane.showMessageDialog(null, "Nilai anda B"); }
    else if (nilai >= 68){
    JOptionPane.showMessageDialog(null, "Nilai anda C");}
    
    else{
    JOptionPane.showMessageDialog(null, "Anda harus ujian ulang");
}
 }
}
