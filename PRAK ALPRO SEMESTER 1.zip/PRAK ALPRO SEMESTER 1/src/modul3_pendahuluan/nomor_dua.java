
package modul3_pendahuluan;

import javax.swing.JOptionPane;

public class nomor_dua {
    public static void main (String[]args){
String nama = "";
int usia ;
nama =JOptionPane.showInputDialog("Masukkan nama anda");

usia=Integer.parseInt(JOptionPane.showInputDialog("usia"));

JOptionPane.showMessageDialog(null, "nama= " + nama + "\nusia= " + usia +" tahun");

}
}
