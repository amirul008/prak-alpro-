
package modul3_pendahuluan;

import javax.swing.JOptionPane;

public class nomor_empat_b {
    public static void main (String[]args){
 int a;
 int b;
 int hasil;
a = Integer.parseInt(JOptionPane.showInputDialog("masukkan angka A"));

b = Integer.parseInt(JOptionPane.showInputDialog("masukkan angka B"));

 hasil = a + b;
JOptionPane.showMessageDialog(null, "angka A = " + a + "\nangka B = " + b + "\na + b = " + hasil);

 }
}
