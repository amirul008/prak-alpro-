
package modul3_pendahuluan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class nomor_satu {
    
    
    public static void main( String[] args ){
      BufferedReader dataIn = new BufferedReader(new InputStreamReader( System.in) );
      String nama = "";
      System.out.print("Masukkan Nama Anda: ");
      try{nama = dataIn.readLine();}
       catch(IOException e){
      System.out.print("Anda salah!");}
      String NIM = "";
      System.out.print("Masukkan NIM anda: ");
      try{
      NIM = dataIn.readLine();
      }
      catch( IOException e ){
       System.out.print("Anda salah!");
       }
       System.out.println("Nama= " + nama + "\nNIM="+NIM +"\nSelamat, Anda berhasil!!!");

}

}
