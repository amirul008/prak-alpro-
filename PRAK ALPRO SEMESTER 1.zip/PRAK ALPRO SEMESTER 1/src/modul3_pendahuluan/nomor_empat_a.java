
package modul3_pendahuluan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class nomor_empat_a {
    public static void main(String[] args)
            throws IOException {
            BufferedReader dataAngka = new BufferedReader(new InputStreamReader(System.in));

            System.out.println("Menghitung penjumlahan ");
            System.out.print("nilai a = ");
            String str1 = dataAngka.readLine();
            int a = Integer.parseInt(str1);
            System.out.print("nilai b = ");
            String str2 = dataAngka.readLine();
            int b = Integer.parseInt(str2);
            int hasil = a+b;
           System.out.println("Angka a = " + a + "\nangka b = " + b + "\na + b = " + hasil );
}
}
