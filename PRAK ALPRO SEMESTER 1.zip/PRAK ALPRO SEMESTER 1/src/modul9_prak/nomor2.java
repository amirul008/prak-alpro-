package modul9_prak;

import java.awt.Color;
import javax.swing.*;

public class nomor2 extends JFrame {

    JTextField textField = new JTextField();
    JButton zero = new JButton("0");
    JButton satu = new JButton("1");
    JButton dua = new JButton("2");
    JButton tiga = new JButton("3");
    JButton empat = new JButton("4");
    JButton lima = new JButton("5");
    JButton enam = new JButton("6");
    JButton tujuh = new JButton("7");
    JButton delapan = new JButton("8");
    JButton sembilan = new JButton("9");
    JButton tambah = new JButton("+");
    JButton kurang = new JButton("-");
    JButton kali = new JButton("*");
    JButton bagi = new JButton("/");
    JButton samaDengan = new JButton("=");
    JButton c = new JButton("C");

    nomor2() {
        setTitle("Design Preview");
        setSize(230, 270);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        setVisible(true);
    }

    void objek() {
        setLayout(null);
        textField.setBounds(10, 10, 193, 30);

        add(textField);
        satu.setBounds(10, 60, 41, 25);

        add(satu);
        dua.setBounds(60, 60, 41, 25);

        add(dua);
        tiga.setBounds(110, 60, 41, 25);

        add(tiga);
        tambah.setBounds(160, 60, 41, 25);

        add(tambah);
        empat.setBounds(10, 100, 41, 25);

        add(empat);
        lima.setBounds(60, 100, 41, 25);

        add(lima);
        enam.setBounds(110, 100, 41, 25);

        add(enam);
        kurang.setBounds(160, 100, 41, 25);

        add(kurang);
        tujuh.setBounds(10, 140, 41, 25);

        add(tujuh);
        delapan.setBounds(60, 140, 41, 25);

        add(delapan);
        sembilan.setBounds(110, 140, 41, 25);

        add(sembilan);
        kali.setBounds(160, 140, 41, 25);

        add(kali);
        zero.setBounds(10, 180, 41, 25);

        add(zero);
        c.setBounds(60, 180, 41, 25);

        add(c);
        samaDengan.setBounds(110, 180, 41, 25);

        add(samaDengan);
        bagi.setBounds(160, 180, 41, 25);

        add(bagi);
    }

    public static void main(String[] args) {
        nomor2 x = new nomor2();
        x.objek();
    }

}
