
package modul7_prak;


public class nomor2_d {
    public static void main(String[] args) {
 int data2[][] = {{4, 6, 4, 2, 8, 4, 2, 10}, {4, 6, 4, 2, 8, 4, 2, 10}};
        int  genap = 0, jml = 0;
        for(int a=0; a<data2.length; a++){
            for(int b=0; b<data2[0].length; b++){
                if (data2[a][b] %2 == 0){
                    genap = data2[a][b];
                    jml += genap;
                }
            }
        }System.out.println("Jumlah Element Yang Bernilai Genap : " +jml);
        System.out.println();
    }
}
