
package modul7_prak;

import java.util.Arrays;
import javax.swing.JOptionPane;

public class nomor2_c {
    public static void main(String[] args) {
        int data2[][] = {{4, 6, 4, 2, 8, 4, 2, 10}, {4, 6, 4, 2, 8, 4, 2, 10}};
        String array1 = Arrays.toString(data2[0]);
        String array2 = Arrays.toString(data2[1]);
        
        String baris = JOptionPane.showInputDialog("Masukkan posisi baris yang anda inginkan : \n\n" + array1 + "\n" + array2);
        int baris2 = Integer.parseInt(baris);
        
        String kolom = JOptionPane.showInputDialog("Masukkan posisi kolom yang anda inginkann : \n\n" + array1 + "\n" + array2);
        int kolom2 = Integer.parseInt(kolom);
        
        String ganti = JOptionPane.showInputDialog("Masukkan element baru yang anda inginkan : \n\n" + array1 + "\n" + array2);
        int ganti2 = Integer.parseInt(ganti);
        
        data2[baris2][kolom2] = ganti2;
        
        array1 = Arrays.toString(data2[0]);
        array2 = Arrays.toString(data2[1]);
        
        String pesan2 = "sesudah diganti \n " + array1 + "\n" + array2 + "\n";
        JOptionPane.showMessageDialog(null,pesan2);
    }
}
