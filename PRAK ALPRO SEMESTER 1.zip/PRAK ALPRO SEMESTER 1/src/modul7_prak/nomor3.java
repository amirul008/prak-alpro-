
package modul7_prak;

public class nomor3 {
    public static void main(String[] args) {
        String data [][] = {{"ABDUL", "Kediri", "085646668991"}, {"KUSNO", "Trenggalek", 
                            "085646668992"}, {"PONIRAN", "Bojonegoro", "085646668999"}};
        for (int i=0;i<3;i++){
            for (int j=0;j<3;j++){
                System.out.print(data[i][j]+" ");
            }
            System.out.println();
        }
    }
}
