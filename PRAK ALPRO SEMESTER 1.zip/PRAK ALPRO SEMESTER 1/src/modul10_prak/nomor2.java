package modul10_prak;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class nomor2 extends JFrame {

    JTextField kotak1 = new JTextField();
    JButton satu = new JButton("1");
    JButton dua = new JButton("2");
    JButton tiga = new JButton("3");
    JButton tambah = new JButton("+");
    JButton empat = new JButton("4");
    JButton lima = new JButton("5");
    JButton enam = new JButton("6");
    JButton min = new JButton("-");
    JButton tujuh = new JButton("7");
    JButton delapan = new JButton("8");
    JButton sembilan = new JButton("9");
    JButton kali = new JButton("*");
    JButton zero = new JButton("0");
    JButton c = new JButton("c");
    JButton samadengan = new JButton("=");
    JButton bagi = new JButton("/");

    nomor2() {
        setTitle("Kalkulator");
        setSize(290, 320);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    double angka = 0;
    double jawab;
    int hitung = 0;

    public void operasi() {
        switch (hitung) {
            case 1:
                jawab = angka + Double.parseDouble(kotak1.getText());
                kotak1.setText(Double.toString(jawab));
                break;

            case 2:
                jawab = angka - Double.parseDouble(kotak1.getText());
                kotak1.setText(Double.toString(jawab));
                break;

            case 3:
                jawab = angka * Double.parseDouble(kotak1.getText());
                kotak1.setText(Double.toString(jawab));
                break;

            case 4:
                jawab = angka / Double.parseDouble(kotak1.getText());
                kotak1.setText(Double.toString(jawab));
                break;
        }
    }

    void objek() {
        tambah.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                angka = Double.parseDouble(kotak1.getText());
                hitung = 1;
                kotak1.setText("");
            }
        });

        min.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                angka = Double.parseDouble(kotak1.getText());
                hitung = 2;
                kotak1.setText("");
            }
        });

        kali.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                angka = Double.parseDouble(kotak1.getText());
                hitung = 3;
                kotak1.setText("");
            }
        });

        bagi .addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                angka = Double.parseDouble(kotak1.getText());
                hitung = 4;
                kotak1.setText("");
            }
        });

        c.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                kotak1.setText("");
            }
        });

        samadengan.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                operasi();
            }

        });
        getContentPane().setLayout(null);
        getContentPane().add(kotak1);
        getContentPane().add(satu);
        getContentPane().add(dua);
        getContentPane().add(tiga);
        getContentPane().add(tambah);
        getContentPane().add(empat);
        getContentPane().add(lima);
        getContentPane().add(enam);
        getContentPane().add(min);
        getContentPane().add(tujuh);
        getContentPane().add(delapan);
        getContentPane().add(sembilan);
        getContentPane().add(kali);
        getContentPane().add(zero);
        getContentPane().add(c);
        getContentPane().add(samadengan);
        getContentPane().add(bagi);

        kotak1.setBounds(15, 10, 245, 33);
        satu.setBounds(15, 60, 50, 35);
        dua.setBounds(80, 60, 50, 35);
        tiga.setBounds(145, 60, 50, 35);
        tambah.setBounds(210, 60, 50, 35);
        empat.setBounds(15, 110, 50, 35);
        lima.setBounds(80, 110, 50, 35);
        enam.setBounds(145, 110, 50, 35);
        min.setBounds(210, 110, 50, 35);
        tujuh.setBounds(15, 160, 50, 35);
        delapan.setBounds(80, 160, 50, 35);
        sembilan.setBounds(145, 160, 50, 35);
        kali.setBounds(210, 160, 50, 35);
        zero.setBounds(15, 210, 50, 35);
        c.setBounds(80, 210, 50, 35);
        samadengan.setBounds(145, 210, 50, 35);
        bagi.setBounds(210, 210, 50, 35);

        satu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                kotak1.setText(kotak1.getText() + "1");
            }
        });

        dua.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                kotak1.setText(kotak1.getText() + "2");
            }
        });

        tiga.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                kotak1.setText(kotak1.getText() + "3");
            }
        });

        empat.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                kotak1.setText(kotak1.getText() + "4");
            }
        });

        lima.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                kotak1.setText(kotak1.getText() + "5");
            }
        });

        enam.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                kotak1.setText(kotak1.getText() + "6");
            }
        });

        tujuh.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                kotak1.setText(kotak1.getText() + "7");
            }
        });

        delapan.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                kotak1.setText(kotak1.getText() + "8");
            }
        });

        sembilan.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                kotak1.setText(kotak1.getText() + "9");
            }
        });

        zero.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                kotak1.setText(kotak1.getText() + "0");
            }
        });
    }

    public static void main(String[] args) {
        nomor2 kedua = new nomor2();
        kedua.objek();
        kedua.operasi();
    }
}
