package modul5_prak;


public class nomor2_b {
    public static void main(String[] args) {
        int a=1;
        int jumlah = 1;
        int b=1;
        int jumlah2 = 1;
        int jumlah_total=1;
        System.out.println("---Bilangan pertama---");
        do{
            a++;
            System.out.println(a); 
            jumlah*=a;
            
        }while(a < 5);
        System.out.println("Total dari 5 angka perulangan = "+jumlah);
        
        System.out.println("---Bilangan kedua---");
        do{
            b++;
            System.out.println(b); 
            jumlah2*=b;
            
        }while(b < 4);
        System.out.println("Total dari 4 angka perulangan = "+jumlah2);
        jumlah_total=jumlah+jumlah2;
        
        System.out.println("Total dari 5! +4! adalah = " + jumlah_total);
        
    }
}
