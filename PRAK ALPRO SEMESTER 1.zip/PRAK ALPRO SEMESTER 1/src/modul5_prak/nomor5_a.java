package modul5_prak;


import javax.swing.JOptionPane;


public class nomor5_a {
    
    public static void main(String[] args) {
        String angka = JOptionPane.showInputDialog("Masukkan angka : ");
        int n = Integer.parseInt(angka);
        for (int i = 1;i<=n;i++){
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
                System.out.println();
            }
    }
}
