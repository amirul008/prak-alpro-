package modul5_prak;


import javax.swing.JOptionPane;


public class nomor5_b {
    public static void main(String[] args) {
         String angka = JOptionPane.showInputDialog("Masukkan Angka : ");
        System.out.println("Output pertama");
        int n = Integer.parseInt(angka);
        for(int i=1;i<=n;i++){
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }System.out.print("\t");
            for(int j=n;j>=i;j--){
                System.out.print("*");
            }System.out.print("\t");
            System.out.println("");
            }
        System.out.println("Output kedua");
        for(int i=1;i<=n;i++){
            for(int j=n;j>=i;j--){
                System.out.print("*");
            }System.out.print("\t");
            for(int j=n;j>=i;j--){
                System.out.print("*");
            }System.out.print("\t");
            System.out.println("");
            }
    }
}
