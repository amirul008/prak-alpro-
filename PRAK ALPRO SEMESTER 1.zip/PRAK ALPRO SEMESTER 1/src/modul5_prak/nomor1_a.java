package modul5_prak;


public class nomor1_a {
    public static void main(String[] args) {
        {
            int jml=0;
            for (int i=1;i<=10;i++){
                jml+=i;
            }
            System.out.println("Jumlah semua bilangan : " +jml);
        }
    }
}

