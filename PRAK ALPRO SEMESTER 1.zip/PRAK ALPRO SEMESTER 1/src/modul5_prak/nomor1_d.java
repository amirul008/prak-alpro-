package modul5_prak;


public class nomor1_d {
    public static void main(String[] args) {
        double r=0;
        do{
            r=Math.random();
            System.out.println(r);
        }
        while(r<0.99d);
    }
    
}
