package modul5_prak;


public class nomor1_c {
    public static void main(String[] args) {
        double r=0;
        while(r<0.99d){
        r=Math.random();
            System.out.println(r);
        }
    }
}
