package modul5_prak;


import java.util.Scanner;


public class nomor2_a {
    public static void main(String[] args) {
    int hasil = 1;
    int hasil2 = 1;
    int hasil_total =1;

    int angka, pangkat; 
    int angka2, pangkat2;
  

    Scanner a = new Scanner(System.in); 
    
    System.out.println("--------------------------------");

         System.out.print("Masukkan Angka : ");

         angka = a.nextInt();

         System.out.print("Masukkan Pangkat : ");

         Scanner b = new Scanner(System.in);

         pangkat = b.nextInt();

         for(int i=1; i<=pangkat; i++){

         hasil=hasil*angka; //rumus

     }
         
    Scanner c = new Scanner(System.in); 
    
    System.out.println("--------------------------------");

     System.out.print("Masukkan Angka : ");

         angka2 = c.nextInt();

         System.out.print("Masukkan Pangkat : ");

         Scanner d = new Scanner(System.in);

         pangkat2 = d.nextInt();

         for(int i=1; i<=pangkat2; i++){

         hasil2=hasil2*angka2; //rumus
         
         hasil_total=hasil+hasil2;

     }
         


         System.out.println("Hasil "+angka+" pangkat "+pangkat+" + "+angka2+" pangkat "+pangkat2+" = "+hasil_total);

     
    }
}
