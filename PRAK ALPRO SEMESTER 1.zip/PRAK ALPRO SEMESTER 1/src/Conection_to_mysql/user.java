/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conection_to_mysql;

/**
 *
 * @author ASUS
 */
public class user {
     private String nim;
    private String nama;
    private String kelas;
    private String matkul;
    
    
    public user(String NIM ,String Nama,String Kelas,String Matkul)
    {
        this.nim = NIM;
        this.nama = Nama;
        this.kelas = Kelas;
        this.matkul = Matkul;
    }
    
    public String getNim()
    {
        return nim;
    }
    
    public String getNama()
    {
        return nama;
    }
    
    public String getKelas()
    {
        return kelas;
    }
    
    public String getMatkul()
    {
        return matkul;
    }
}
