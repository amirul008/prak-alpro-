/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conection_to_mysql;

import modul11_pendahuluan.*;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class data_mahasiswa extends javax.swing.JFrame {

    private DefaultTableModel model;
    public static Statement stm;
    public static ResultSet res;
    public static ResultSet RsProduk=null;

    public data_mahasiswa() throws SQLException {
        initComponents();
//        tabeldata();
        tampildata();

    }

    @SuppressWarnings("unchecked")
    private void GetData() {
        try {
            Connection con = (Connection) Conection_to_mysql.koneksi.koneksiDB();
            Statement stm = con.createStatement();
            ResultSet sql = stm.executeQuery("select * from m_amirul_m_210605110020");

        } catch (Exception e) {
        }
    }
    String[] data;

//    private void kliktable() {
//        int baris = tabel.getSelectedRow();
//        nim.setText((String) tabel.getValueAt(baris, 0));
//        nama.setText((String) tabel.getValueAt(baris, 1));
////        kelas.setSelectedItem((String)tabel.getValueAt(baris, 2));
//        matkul.setSelectedItem((String) tabel.getValueAt(baris, 2));
//    }
//
//    private DefaultTableModel tabmode;
//
//    //menampilkan data dari datatabe ke tabel
//    public void tabeldata() {
//        Object[] baris = {"NIM", "Nama", "Kelas", "Mata Kuliah"};
//        tabmode = new DefaultTableModel(null, baris);
//        tabel.setModel(tabmode);
//        try {
//            Connection con = new koneksi().koneksiDB();
//            String sql = "select * from m_amirul_m_210605110020 order by NIM asc";
//            java.sql.Statement stat = con.createStatement();
//            java.sql.ResultSet hasil = stat.executeQuery(sql);
//            while (hasil.next()) {
//                String nim = hasil.getString("nim");
//                String nama = hasil.getString("nama");
//                String kelas = hasil.getString("kelas");
//                String matkul = hasil.getString("matkul");
//                String[] data = {nim, nama, kelas, matkul};
//                tabmode.addRow(data);
//            }
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, "GAGAL menampilkan data !", "Informasi", JOptionPane.INFORMATION_MESSAGE);
//        }
//    }
//
//    public ArrayList<user> ListUsers(String ValToSearch) {
//        ArrayList<user> usersList = new ArrayList<user>();
//
//        Statement st;
//        ResultSet rs;
//
//        try {
//            Connection con = new koneksi().koneksiDB();
//            st = con.createStatement();
//            String searchQuery = "SELECT * FROM `m_amirul_m_210605110020` WHERE nim(nim, nama, kelas, matkul) LIKE '%" + ValToSearch + "%'";
//            rs = st.executeQuery(searchQuery);
//
//            user user;
//
//            while (rs.next()) {
//                user = new user(
//                        rs.getString("nim"),
//                        rs.getString("nama"),
//                        rs.getString("kelas"),
//                        rs.getString("matkul")
//                );
//                usersList.add(user);
//            }
//
//        } catch (Exception ex) {
//            System.out.println(ex.getMessage());
//        }
//
//        return usersList;
//    }
    
       private void tampildata(){
        try{
           Object[] judul_kolom = {"nim", "nama", "kelas", "matkul"};
            model=new DefaultTableModel(null,judul_kolom);
            tabel.setModel(model);
            
            Connection conn= new koneksi().koneksiDB();
            Statement stt=conn.createStatement();
            model.getDataVector().removeAllElements();
           
            RsProduk=stt.executeQuery("SELECT * from m_amirul_m_210605110020");  
            while(RsProduk.next()){
                Object[] data={
                    RsProduk.getString("nim"),
                    RsProduk.getString("nama"),
                    RsProduk.getString("kelas"),
                   RsProduk.getString("matkul"),
      
                };
               model.addRow(data);
            }                
        } catch (Exception ex) {
        System.err.println(ex.getMessage());
        }
    }

    // function to display data in jtable
//    public void findUsers() {
//        ArrayList<user> users = ListUsers(cari_tabel.getText());
//        DefaultTableModel model = new DefaultTableModel();
//        model.setColumnIdentifiers(new Object[]{"nim", "nama", "kelas", "matkul"});
//        Object[] row = new Object[4];
//
//        for (int i = 0; i < users.size(); i++) {
//            row[0] = users.get(i).getNim();
//            row[1] = users.get(i).getNama();
//            row[2] = users.get(i).getKelas();
//            row[3] = users.get(i).getMatkul();
//            model.addRow(row);
//        }
//        tabel.setModel(model);
//
//    }
    private void cariData(String key){
        try{
           Object[] judul_kolom = {"nim", "nama", "kelas", "matkul"};
            model=new DefaultTableModel(null,judul_kolom);
            tabel.setModel(model);
            
            Connection conn= new koneksi().koneksiDB();
            Statement stt=conn.createStatement();
            model.getDataVector().removeAllElements();
           
            RsProduk=stt.executeQuery("SELECT * from m_amirul_m_210605110020 WHERE nim LIKE '%"+key+"%' ");  
            while(RsProduk.next()){
                Object[] data={
                    RsProduk.getString("nim"),
                    RsProduk.getString("nama"),
                    RsProduk.getString("kelas"),
                   RsProduk.getString("matkul"),
      
                };
               model.addRow(data);
            }                
        } catch (Exception ex) {
        System.err.println(ex.getMessage());
        }
    }

    private void namaActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void bActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }
    String nime = "";


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        nim = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel = new javax.swing.JTable();
        nama = new javax.swing.JTextField();
        matkul = new javax.swing.JComboBox<>();
        edit = new javax.swing.JButton();
        simpan = new javax.swing.JButton();
        hapus = new javax.swing.JButton();
        keluar = new javax.swing.JButton();
        label_nim = new javax.swing.JLabel();
        label_nama = new javax.swing.JLabel();
        label_kelas = new javax.swing.JLabel();
        label_matkul = new javax.swing.JLabel();
        a = new javax.swing.JRadioButton();
        b = new javax.swing.JRadioButton();
        c = new javax.swing.JRadioButton();
        cari = new javax.swing.JButton();
        cari_tabel = new javax.swing.JTextField();
        btn_cari = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nimActionPerformed(evt);
            }
        });
        getContentPane().add(nim, new org.netbeans.lib.awtextra.AbsoluteConstraints(86, 20, 164, 30));

        tabel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Nama", "kelas", "Mata Kuliah"
            }
        ));
        jScrollPane1.setViewportView(tabel);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, -1, 97));
        getContentPane().add(nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(86, 63, 293, 33));

        matkul.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-pilih-", "Praktikum algoritma", "kalkulus", "I2CS", "Matematika diskrit", "pancasila" }));
        matkul.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                matkulActionPerformed(evt);
            }
        });
        getContentPane().add(matkul, new org.netbeans.lib.awtextra.AbsoluteConstraints(93, 154, 147, 31));

        edit.setText("edit");
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });
        getContentPane().add(edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(71, 217, 83, -1));

        simpan.setText("simpan");
        simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanActionPerformed(evt);
            }
        });
        getContentPane().add(simpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(161, 217, 84, -1));

        hapus.setText("hapus");
        hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusActionPerformed(evt);
            }
        });
        getContentPane().add(hapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(257, 217, 90, -1));

        keluar.setText("keluar");
        keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keluarActionPerformed(evt);
            }
        });
        getContentPane().add(keluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(354, 217, 91, -1));

        label_nim.setText("NIM");
        getContentPane().add(label_nim, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 27, -1, -1));

        label_nama.setText("Nama");
        getContentPane().add(label_nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 63, 45, 33));

        label_kelas.setText("Kelas");
        getContentPane().add(label_kelas, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 114, 45, 27));

        label_matkul.setText("Mata kuliah ");
        getContentPane().add(label_matkul, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 161, -1, -1));

        a.setText("A");
        a.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aActionPerformed(evt);
            }
        });
        getContentPane().add(a, new org.netbeans.lib.awtextra.AbsoluteConstraints(86, 115, -1, -1));

        b.setText("B");
        getContentPane().add(b, new org.netbeans.lib.awtextra.AbsoluteConstraints(127, 115, -1, -1));

        c.setText("C");
        getContentPane().add(c, new org.netbeans.lib.awtextra.AbsoluteConstraints(162, 115, -1, -1));

        cari.setText("cari");
        cari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariActionPerformed(evt);
            }
        });
        getContentPane().add(cari, new org.netbeans.lib.awtextra.AbsoluteConstraints(284, 20, 95, 30));

        cari_tabel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cari_tabelActionPerformed(evt);
            }
        });
        cari_tabel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cari_tabelKeyReleased(evt);
            }
        });
        getContentPane().add(cari_tabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 290, 130, -1));

        btn_cari.setText("cari tabel");
        btn_cari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cariActionPerformed(evt);
            }
        });
        getContentPane().add(btn_cari, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 290, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void matkulActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_matkulActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_matkulActionPerformed

    private void keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keluarActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_keluarActionPerformed

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        // TODO add your handling code here:
        buttonGroup1.add(a);
        buttonGroup1.add(b);
        buttonGroup1.add(c);

        a.setActionCommand("A");
        b.setActionCommand("B");
        c.setActionCommand("C");

        try {
            String sql = "UPDATE m_amirul_m_210605110020 SET nim='" + nim.getText() + "',"
                    + "nama='" + nama.getText() + "',"
                    + "kelas='" + buttonGroup1.getSelection().getActionCommand() + "',"
                    + "matkul='" + matkul.getSelectedItem().toString() + "' WHERE nim=" + nim.getText();
            Connection conn = Conection_to_mysql.koneksi.koneksiDB();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "berhasil disimpan");

        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }//GEN-LAST:event_editActionPerformed

    private void simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanActionPerformed
        // TODO add your handling code here:

        buttonGroup1.add(a);
        buttonGroup1.add(b);
        buttonGroup1.add(c);

        a.setActionCommand("A");
        b.setActionCommand("B");
        c.setActionCommand("C");
        try {
            String sql = "insert into m_amirul_m_210605110020 values('" + nim.getText() + "',"
                    + "'" + nama.getText() + "',"
                    + "'" + buttonGroup1.getSelection().getActionCommand() + "',"
                    + "'" + matkul.getSelectedItem().toString() + "')";
            Connection conn = Conection_to_mysql.koneksi.koneksiDB();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "berhasil disimpan");
            nim.setText("");
            nama.setText("");
            buttonGroup1.clearSelection();
            matkul.setSelectedIndex(0);
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }//GEN-LAST:event_simpanActionPerformed

    private void hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusActionPerformed
        // TODO add your handling code here:
        buttonGroup1.add(a);
        buttonGroup1.add(b);
        buttonGroup1.add(c);

        a.setActionCommand("A");
        b.setActionCommand("B");
        c.setActionCommand("C");
        try { // hapus data
            String sql = "delete from m_amirul_m_210605110020 where nim='" + nim.getText() + "'";
            java.sql.Connection conn = (java.sql.Connection) Conection_to_mysql.koneksi.koneksiDB();
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Data akan dihapus?");
            nim.setText("");
            nama.setText("");
            buttonGroup1.clearSelection();
            matkul.setSelectedIndex(0);
        } catch (SQLException | HeadlessException e) {
        }
        GetData();

    }//GEN-LAST:event_hapusActionPerformed

    private void cariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariActionPerformed
        // TODO add your handling code here:
        nime = nim.getText();
        try {
            Connection conn = (Connection) Conection_to_mysql.koneksi.koneksiDB();
            Statement ppt = conn.createStatement();
            ResultSet sql = ppt.executeQuery("select * from m_amirul_m_210605110020 where nim=" + nime);

            if (sql.next()) {
                String nimm = sql.getString("nim");
                nim.setText(nimm);
                String namaa = sql.getString("nama");
                nama.setText(namaa);
                String kelass = sql.getString("kelas");
                switch (kelass) {
                    case "A":
                        a.setSelected(true);
                        b.setSelected(false);
                        c.setSelected(false);
                        break;
                    case "B":
                        a.setSelected(false);

                        b.setSelected(true);
                        c.setSelected(false);
                        break;
                    case "C":
                        c.setSelected(true);

                        b.setSelected(false);
                        a.setSelected(false);
                        break;
                    default:
                        break;
                }
                String matkull = sql.getString("matkul");
                switch (matkull) {

                    case "Praktikum algoritma":
                        matkul.setSelectedIndex(1);
                        break;
                    case "kalkulus":
                        matkul.setSelectedIndex(2);
                        break;
                    case "I2CS":
                        matkul.setSelectedIndex(3);
                        break;
                    case "Matematika diskrit":
                        matkul.setSelectedIndex(4);
                        break;
                    case "pancasila":
                        matkul.setSelectedIndex(5);
                        break;
                    default:
                        break;
                }
            }
        } catch (Exception e) {
        }

    }//GEN-LAST:event_cariActionPerformed

    private void nimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nimActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nimActionPerformed

    private void aActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_aActionPerformed

    private void btn_cariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cariActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_btn_cariActionPerformed

    private void cari_tabelKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cari_tabelKeyReleased
        // TODO add your handling code here:
        String key=cari_tabel.getText();
        System.out.println(key);  
        
        if(key!=""){
            cariData(key);
        }else{
            tampildata();
        }
    }//GEN-LAST:event_cari_tabelKeyReleased

    private void cari_tabelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cari_tabelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cari_tabelActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */

//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(data_mahasiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(data_mahasiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(data_mahasiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(data_mahasiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new data_mahasiswa().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(data_mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton a;
    private javax.swing.JRadioButton b;
    private javax.swing.JButton btn_cari;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JRadioButton c;
    private javax.swing.JButton cari;
    private javax.swing.JTextField cari_tabel;
    private javax.swing.JButton edit;
    private javax.swing.JButton hapus;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton keluar;
    private javax.swing.JLabel label_kelas;
    private javax.swing.JLabel label_matkul;
    private javax.swing.JLabel label_nama;
    private javax.swing.JLabel label_nim;
    private javax.swing.JComboBox<String> matkul;
    private javax.swing.JTextField nama;
    private javax.swing.JTextField nim;
    private javax.swing.JButton simpan;
    private javax.swing.JTable tabel;
    // End of variables declaration//GEN-END:variables
}
