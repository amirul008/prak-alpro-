package modul6_pendahuluan;


public class nomor5_while {
    public static void main(String[] args) {
        int data[]={4,6,4,2,8,4,2,11};
        int i=0;
        while ( i<data.length){
            System.out.println("nilai = "+data[i]+" adalah indeks ke-" +i);
            i++;
        }
    }
}
