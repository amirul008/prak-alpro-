/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul2_pendahuluan;

/**
 *
 * @author ASUS
 */
public class Modul2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int number = 10;
        char letter = 'a';
        boolean result = true;
        String str = "hello";
        
        
       System.out.println("Number = 10");
       System.out.println("letter = a");
       System.out.println("result = true");
       System.out.println("str = hello");
       
    }
    
}
