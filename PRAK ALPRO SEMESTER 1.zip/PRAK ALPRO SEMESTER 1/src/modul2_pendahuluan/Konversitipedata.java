/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul2_pendahuluan;

/**
 *
 * @author ASUS
 */
public class Konversitipedata {

    public static void main(String[] args) {
        String data_integer="100";
        String data2_integer="825";
        String data_float="254.70";
        
        byte kon_byte=Byte.valueOf(data_integer);
        Short kon_short=Short.parseShort(data2_integer);
        int kon_int=Integer.parseInt(data2_integer);
        long kon_long = Long.valueOf(data2_integer);
        
        float kon_float = Float.valueOf(data_float);
        double kon_double= Double.parseDouble(data_float);
        
        System.out.println("Test Konversi Byte:" +kon_byte/5);
        System.out.println("Test konversi Short:" +kon_short*4);
        System.out.println("Test Konversi Int:" +kon_int+3000);
        System.out.println("Test Konversi Long:" +kon_long*100);
        System.out.println("Test Konversi Float:" +kon_float/3);
        System.out.println("Test Konversi double:" +kon_double+4559.90);
        
    }
    
}
