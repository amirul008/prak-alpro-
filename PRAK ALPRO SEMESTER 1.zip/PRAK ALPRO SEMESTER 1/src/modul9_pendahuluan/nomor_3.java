package modul9_pendahuluan;

import java.awt.*;
import javax.swing.*;

public class nomor_3 {

    public static void main(String[] args) {
        JFrame form = new JFrame("Design");
        form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        form.setSize(200, 350);
        form.setLocationRelativeTo(null);
        form.setLayout(null);
        form.setVisible(true);

        JLabel label1 = new JLabel("Masukkkan angka pertama : ");
        label1.setBounds(20, 0, 180, 65);
        form.add(label1);

        JTextField set1 = new JTextField();
        set1.setBounds(40, 45, 120, 25);
        form.add(set1);

        JLabel label2 = new JLabel("Masukkkan angka kedua : ");
        label2.setBounds(30, 70, 180, 65);
        form.add(label2);

        JTextField set2 = new JTextField();
        set2.setBounds(40, 115, 120, 25);
        form.add(set2);

        JLabel label3 = new JLabel("Masukkkan angka pertama : ");
        label3.setBounds(20, 140, 180, 65);
        form.add(label3);

        JTextField set3 = new JTextField();
        set3.setBounds(40, 185, 120, 25);
        form.add(set3);

        JButton plus = new JButton();
        plus.setText("+");
        plus.setBounds(30, 220, 45, 25);
        form.add(plus);

        JButton min = new JButton();
        min.setText("-");
        min.setBounds(80, 220, 45, 25);
        form.add(min);

        JButton bagi = new JButton();
        bagi.setText("/");
        bagi.setBounds(135, 220, 45, 25);
        form.add(bagi);

        JButton kali = new JButton();
        kali.setText("*");
        kali.setBounds(80, 255, 45, 25);
        form.add(kali);

    }
}
