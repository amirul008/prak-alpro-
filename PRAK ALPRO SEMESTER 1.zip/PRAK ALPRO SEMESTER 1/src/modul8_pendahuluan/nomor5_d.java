
package modul8_pendahuluan;
public class nomor5_d {
    public static void main (String [] args){
      
      int angka = 50;
      
      System.out.println("angka int adalah = " + angka);
}
}
