package modul10_pendahuluan;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class nomor3 extends JFrame {

    JLabel Label1 = new JLabel("Masukkan Angka Pertama :");
    JLabel Label2 = new JLabel("Masukkan Angka Kedua :");
    JLabel Label3 = new JLabel("Masukkan Angka Pertama :");
    JTextField textField1 = new JTextField();
    JTextField textField2 = new JTextField();
    JTextField textField3 = new JTextField();
    Button Button1 = new Button("+");
    Button Button2 = new Button("-");
    Button Button3 = new Button("/");
    Button Button4 = new Button("*");

    nomor3() {
        setTitle("Program Pendahuluan nomor 3");
        setSize(220, 320);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        setVisible(true);
    }

    void objek() {
        getContentPane().setLayout(null);
        add(Label1);
        add(Label2);
        add(Label3);
        add(textField1);
        add(textField2);
        add(textField3);
        add(Button1);
        add(Button2);
        add(Button3);
        add(Button4);
        Label1.setBounds(25, 5, 170, 25);
        Label2.setBounds(25, 70, 170, 25);
        Label3.setBounds(25, 135, 170, 25);
        textField1.setBounds(40, 35, 125, 25);
        textField2.setBounds(40, 100, 125, 25);
        textField3.setBounds(40, 165, 125, 25);
        Button1.setBounds(30, 200, 45, 25);
        Button2.setBounds(80, 200, 45, 25);
        Button3.setBounds(130, 200, 45, 25);
        Button4.setBounds(80, 230, 45, 25);
        Button1.setBackground(Color.WHITE);
        Button2.setBackground(Color.WHITE);
        Button3.setBackground(Color.WHITE);
        Button4.setBackground(Color.WHITE);
    }

    void reaksi() {
        Button1.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int angka1 = Integer.parseInt(textField1.getText());
                int angka2 = Integer.parseInt(textField2.getText());
                int hasil = angka1 + angka2;
                textField3.setText(Integer.toString(hasil));
            }
        });

        Button2.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int angka1 = Integer.parseInt(textField1.getText());
                int angka2 = Integer.parseInt(textField2.getText());
                int hasil = angka1 - angka2;
                textField3.setText(Integer.toString(hasil));
            }
        });

        Button3.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int angka1 = Integer.parseInt(textField1.getText());
                int angka2 = Integer.parseInt(textField2.getText());
                double hasil = angka1 / angka2;
                textField3.setText(Double.toString(hasil));
            }
        });

        Button4.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int angka1 = Integer.parseInt(textField1.getText());
                int angka2 = Integer.parseInt(textField2.getText());
                int hasil = angka1 * angka2;
                textField3.setText(Integer.toString(hasil));
            }
        });
    }

    public static void main(String[] args) {
        nomor3 x = new nomor3();
        x.objek();
        x.reaksi();

    }
}
