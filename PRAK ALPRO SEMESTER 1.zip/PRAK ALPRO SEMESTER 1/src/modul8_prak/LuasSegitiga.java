
package modul8_prak;
import javax.swing.*;
public class LuasSegitiga {
    private static double LuasSegitiga(int alas, int tinggi) {
        double luasSegitiga = alas * tinggi / 2;
        System.out.println("Segitiga");
        System.out.println("Alas = " + alas);
        System.out.println("Tinggi = " + tinggi);
        System.out.println("Luas Segitiga = " + luasSegitiga);
        return luasSegitiga;

    }

    public static void main(String[] args) {

        Double LuasST;
        int alas = Integer.parseInt(JOptionPane.showInputDialog
        ("Untuk menghitung Luas Segitiga\n(Masukkan Alas Segitiga)"));
        int tinggi = Integer.parseInt(JOptionPane.showInputDialog
        ("Masukkan Tinggi Segitiga"));
        LuasST = LuasSegitiga(alas, tinggi);
    }
}
