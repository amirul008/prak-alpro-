
package modul8_prak;

import java.util.Scanner;

public class VolumeKerucut {
    // Fungsi
    public double volume_kerucut (double d,double t) {
        
        double r=d/2;
        double v=Math.PI* Math.pow (r, 2)*t/3;
        return v;  
    }
// Prosedur
    public void hitungVolume (double r, double t) { 
        double v=Math.PI* Math.pow (r, 2)*t/3;
//        System.out.println (v);
        
    }
    
    public static void main(String[] args)  {
        Scanner input=new Scanner(System.in);
        
        System.out.println("Menghitung Volume Kerucut");
        System.out.print("\nMasukkan Diameter: ");
        double d =input.nextDouble(); 
        
        System.out.print("Masukkan Tinggi: ");
        double t =input.nextDouble();
        
        VolumeKerucut Vol=new VolumeKerucut(); 
        
        System.out.println ( "\nVolume Tabung= "+Vol.volume_kerucut(d, t)+" cm"); 
        
    }
}
