package modul8_prak;

import java.util.Scanner;

public class VolumeTabung {

    // Fungsi
    public double volume_tabung(double r, double t) {

        double v = Math.PI * Math.pow(r, 2) * t;
        return v;
    }
// Prosedur

    public void hitungVolume(double r, double t) {
        double v = Math.PI * Math.pow(r, 2) * t;
//        System.out.println (v);

    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Menghitung Volume Tabung");
        System.out.print("\nMasukkan Diameter: ");
        double diameter = input.nextDouble();
        double r = diameter / 2;

        System.out.print("Masukkan Tinggi: ");
        double t = input.nextDouble();

        VolumeTabung Vol = new VolumeTabung();

        System.out.println("\nVolume Tabung= " + Vol.volume_tabung(r, t) + " cm");

    }
}
