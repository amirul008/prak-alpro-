package modul8_prak;

import javax.swing.*;

public class luasLingkaran {

    private static double LuasLingkaran(double jari2) {
        double luasL = Math.PI * Math.pow(jari2, 2);
        System.out.println("Luas Lingkaran");
        System.out.println("Jari-Jari = " + jari2);
        System.out.println("Luas Lingkaran = " + luasL);
        return luasL;

    }

    public static void main(String[] args) {

        Double luasL;
        int jari2 = Integer.parseInt(JOptionPane.showInputDialog("Untuk Menghitung Luas Lingkaran\n(Masukkan Jari-jari)"));
        luasL = LuasLingkaran(jari2);
    }
}
