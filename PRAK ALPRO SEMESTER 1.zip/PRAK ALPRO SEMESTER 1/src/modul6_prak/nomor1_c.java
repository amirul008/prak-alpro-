package modul6_prak;


import javax.swing.*;

public class nomor1_c {
    public static void main(String[] args) {
        int data[] = new int[10];
        for ( int a=0; a<data.length; a++){
            data[a]=Integer.parseInt(JOptionPane.showInputDialog(" Masukkan nilai index ke "+a));
            System.out.println(" Index ke "+a+ " adalah "+data[a]);
              
        }
    }
}
