package modul5_pendahuluan;




public class w_hile {
    public static void main(String[] args) {
        
       int a=0;
       int jumlah=0;
        while (a<=9){
            a++;
            System.out.print("\n Bilangan ke : "+a);
            jumlah+=a;
            
        }     
        System.out.println("\ntotal penjumlahan = "+jumlah);
    }
}
