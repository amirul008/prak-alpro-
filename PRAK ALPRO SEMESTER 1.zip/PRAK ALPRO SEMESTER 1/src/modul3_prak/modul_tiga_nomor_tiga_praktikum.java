package modul3_prak;


import javax.swing.JOptionPane;


public class modul_tiga_nomor_tiga_praktikum {
    
       public static void main(String[] args) {
          int a;
          int b;
          int c;
          
          a = Integer.parseInt(JOptionPane.showInputDialog("Masukkan nilai pertama"));
          b = Integer.parseInt(JOptionPane.showInputDialog("Masukkan nilai kedua"));
          c = Integer.parseInt(JOptionPane.showInputDialog("Masukkan nilai ke dua"));
          
          JOptionPane.showMessageDialog(null,"Nilai - nilai yang dimasukkan ="+a+"," +b+ "," +c);
          
          
}
}