package modul3_prak;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class modul_tiga_nomor_satu_praktikum {

    public static void main(String[] args) 
       throws IOException {
            BufferedReader dataAngka = new BufferedReader(new InputStreamReader(System.in));

            System.out.println("Masukkan nilai anda !");
            System.out.print("Masukkan nilai pertama = ");
            String str1 = dataAngka.readLine();
            int a = Integer.parseInt(str1);
            System.out.print("Masukkan nilai kedua = ");
            String str2 = dataAngka.readLine();
            int b = Integer.parseInt(str2);
            System.out.print("Masukkan nilai Ke dua =");
            String str3 = dataAngka.readLine();
            int c = Integer.parseInt(str3);
           System.out.println("Nilai - nilai yang dimasukkan ="+a+","+b+","+c );
}
}
    
    

